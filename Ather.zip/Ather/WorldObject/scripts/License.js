/**
 * (c) Meta Platforms, Inc. and affiliates. Confidential and proprietary.
 */
//==============================================================================
// By downloading, installing, accessing or using Meta Spark Studio Templates (“Templates”),
// you agree to be bound by and become a party to the Meta Spark Studio Terms
// [https://sparkar.facebook.com/ar-studio/terms/] (the “Terms”).  Subject to your compliance with
// the Terms and all other applicable terms and policies, and in addition to the rights granted therein,
// you are hereby granted a non-exclusive, revocable, worldwide, royalty-free license to reproduce, modify,
// create derivative works of, and distribute the Templates in order to create content to be published on
// Meta Products [https://www.facebook.com/help/1561485474074139]. You may not use the Templates for
// any purpose other than to create content for use with Meta Products.
// Copyright (c) 2016-present, Meta Platforms, Inc. All rights reserved
//==============================================================================